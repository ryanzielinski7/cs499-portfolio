package com.cs320;

import java.util.HashMap;
import java.util.Map;

/**
 * TaskService manages Task objects using a HashMap for O(1) average-time
 * insertion, lookup, updates, and deletion.
 *
 * This enhancement replaces the original ArrayList-based implementation
 * to eliminate linear searches and improve algorithmic efficiency.
 */
public class TaskService {

    private static final String CONTEXT = "TaskService";

    /**
     * Internal storage:
     * Key   = taskId
     * Value = Task
     *
     * HashMap choice:
     *  - O(1) average lookup
     *  - Previously O(n) scans eliminated
     */
    private final Map<String, Task> tasks = new HashMap<>();

    /** Add a new task if ID is unique */
    public void addTask(Task task) {
        ValidationUtils.requireNonNull(task, "Task cannot be null");
        ValidationUtils.requireNonEmpty(task.getTaskId(), "Task ID cannot be empty");

        if (tasks.containsKey(task.getTaskId())) {
            Logger.error(CONTEXT, "Duplicate task ID: " + task.getTaskId());
            throw new IllegalArgumentException("Task ID already exists");
        }

        tasks.put(task.getTaskId(), task);
        Logger.info(CONTEXT, "Added task with ID: " + task.getTaskId());
    }

    /** Remove task by ID */
    public void deleteTask(String taskId) {
        Task existing = requireTaskExists(taskId);
        tasks.remove(existing.getTaskId());
        Logger.info(CONTEXT, "Deleted task with ID: " + taskId);
    }

    /** Update task name */
    public void updateTaskName(String taskId, String newName) {
        Task existing = requireTaskExists(taskId);
        existing.setName(newName);
        Logger.info(CONTEXT, "Updated task name for ID: " + taskId);
    }

    /** Update task description */
    public void updateTaskDescription(String taskId, String newDescription) {
        Task existing = requireTaskExists(taskId);
        existing.setDescription(newDescription);
        Logger.info(CONTEXT, "Updated task description for ID: " + taskId);
    }

    /** Return task or null (not an exception — required for unit tests) */
    public Task getTask(String taskId) {
        ValidationUtils.requireNonEmpty(taskId, "Task ID cannot be empty");
        return tasks.get(taskId);
    }

    /** Helper: ensures task exists */
    private Task requireTaskExists(String taskId) {
        ValidationUtils.requireNonEmpty(taskId, "Task ID cannot be empty");
        Task t = tasks.get(taskId);
        if (t == null) {
            Logger.error(CONTEXT, "Task not found: " + taskId);
            throw new IllegalArgumentException("Task ID not found");
        }
        return t;
    }
}

